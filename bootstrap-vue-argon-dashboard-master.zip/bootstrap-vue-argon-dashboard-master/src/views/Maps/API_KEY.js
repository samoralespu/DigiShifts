export const API_KEY = 'YOUR_API_KEY';
